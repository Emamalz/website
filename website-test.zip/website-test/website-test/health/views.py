from django.shortcuts import render, redirect, get_object_or_404
from .forms import SelectTeamForm, HealthCheckEntryForm
from .models import Team, HealthCheckEntry
from django.db.models import Count, Q
from django.utils.safestring import mark_safe
import json
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views.generic import CreateView

from .forms import RegisterForm


class RegisterView(CreateView):
    form_class = UserCreationForm
    template_name = "registration/register.html"
    success_url = reverse_lazy("select_role")  # Redirect to role page after registration


@login_required
def select_role_view(request):
    if request.method == 'POST':
        selected_role = request.POST.get('role')
        request.session['user_role'] = selected_role  # Optional: store for later use
        return redirect('select_team')
    return render(request, 'select_role.html')


def select_team(request):
    if request.method == 'POST':
        form = SelectTeamForm(request.POST)
        if form.is_valid():
            team = form.cleaned_data['team']
            request.session['team_id'] = team.id
            return redirect('intro_page')
    else:
        form = SelectTeamForm()
    return render(request, 'details.html', {'form': form})





@login_required
def intro_page(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')
    return render(request, 'Intro.html')





def done(request):
    return render(request, 'done.html')


def deliver(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Delivering Value'
            entry.save()
            return redirect('ease_of_release')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Deliver.html', {'form': form})


def ease_of_release(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Ease of Release'
            entry.save()
            return redirect('healthbasecoder')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Easeofrelease.html', {'form': form})


def healthbasecoder(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Health of Codebase'
            entry.save()
            return redirect('learning')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Healthbasecoder.html', {'form': form})


def learning(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Learning'
            entry.save()
            return redirect('fun')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Learning.html', {'form': form})


def fun(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Fun'
            entry.save()
            return redirect('suitable_process')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Fun.html', {'form': form})


def suitable_process(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Suitable Process'
            entry.save()
            return redirect('speed')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Suitable process.html', {'form': form})


def speed(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Speed'
            entry.save()
            return redirect('mission')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Speed.html', {'form': form})


def mission(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Mission'
            entry.save()
            return redirect('support')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Mission.html', {'form': form})


def support(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Support'
            entry.save()
            return redirect('pawnsonplayers')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'Support.html', {'form': form})


def pawnsonplayers(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return redirect('select_team')

    team = Team.objects.get(id=team_id)

    if request.method == 'POST':
        form = HealthCheckEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.team = team
            entry.card_title = 'Pawns or Players'
            entry.save()
            return redirect('done')
    else:
        form = HealthCheckEntryForm()

    return render(request, 'pawnsonplayers.html', {'form': form})


def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect("select_role")
        return render(request, "registration/Login.html", {"error": "Wrong credentials"})

    return render(request, "registration/Login.html")


def logout_view(request):
    logout(request)
    return redirect("/")


def feedback(request): return render(request, 'feedback.html')
def trends(request): return render(request, 'trends.html')
def login(request): return render(request, 'Login.html')
def logout(request): return render(request, 'logout.html')
def factors(request): return render(request, 'factors.html')


def factors_view(request):
    team_id = request.session.get('team_id')
    if not team_id:
        return render(request, 'factors.html', {
            'error': 'No team selected. Please fill out the health check first.'
        })

    team = get_object_or_404(Team, id=team_id)
    entries = HealthCheckEntry.objects.filter(team=team)

    factor_data = {}
    for card in entries.values_list('card_title', flat=True).distinct():
        counts = entries.filter(card_title=card).values('status').annotate(count=Count('id'))
        factor_data[card] = {'Green': 0, 'Amber': 0, 'Red': 0}
        for row in counts:
            status = row['status']
            if status in factor_data[card]:
                factor_data[card][status] = row['count']

    return render(request, 'factors.html', {
        'factor_data': mark_safe(json.dumps(factor_data)),
        'team_name': team.name
    })


def trends_view(request):
    qs = (
        HealthCheckEntry.objects
        .values('team__name', 'status')
        .annotate(count=Count('id'))
    )

    chart_data = {}
    for row in qs:
        team = row['team__name']
        status = row['status']
        count  = row['count']
        chart_data.setdefault(team, {'Green': 0, 'Amber': 0, 'Red': 0})
        if status in chart_data[team]:
            chart_data[team][status] = count

    context = {
        "chart_data": mark_safe(json.dumps(chart_data))
    }
    return render(request, "teams_comparison.html", context)
